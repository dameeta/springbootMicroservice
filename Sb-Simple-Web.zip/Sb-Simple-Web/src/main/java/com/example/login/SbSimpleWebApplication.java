package com.example.login;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SbSimpleWebApplication {

	public static void main(String[] args) {
		SpringApplication.run(SbSimpleWebApplication.class, args);
	}

}
